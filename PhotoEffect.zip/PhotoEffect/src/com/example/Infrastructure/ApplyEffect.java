package com.example.Infrastructure;

import android.graphics.Bitmap;

public interface ApplyEffect {

	Bitmap applyEffect(Bitmap source);
	
}
